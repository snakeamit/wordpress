<?php
<html>
<head>
<script>

</script>
</head>
<body>
<p>Hello</p>
</body>
</html>
?>