<?php
    ob_start();
    header("Location: home");
    #header("Location: be-back");
    ob_end_flush();
    die();
?>
 