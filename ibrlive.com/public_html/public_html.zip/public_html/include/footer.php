  <footer class="main-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-2"> 
          <a href="/privacy-policy">Privacy Policy</a>
        </div>
        <div class="col-md-2">
          <a href="/terms-and-conditions">Terms and Conditions</a>
        </div>
        <div class="col-md-2">
          <a href="/refund-cancellation">Refund and Cancellation</a>
        </div>
        <div class="col-md-4">
          <strong>Copyright &copy; <?php echo date("Y"); ?> <a href="https://www.ibrlive.com">IBRLive India Private Limited</a>. All rights reserved.</strong>
        </div>
        <div class="col-md-2">
          Developed by: <a target="_blank" href="https://www.robozx.com/">RobozX</a>
        </div>
      </div>
    
    </div>
    <!-- /.container -->
    
  </footer>
  
