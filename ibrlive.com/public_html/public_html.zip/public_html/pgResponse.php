<?php
if(session_id()=='' || !isset($_SESSION)){
    session_start();
}

// include database configuration file
include 'dbConfig.php';
?>
<!DOCTYPE html>
<html>
<head><meta charset="windows-1252">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Payment Status | IBR Live</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="css/style.css">
  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
     
  <style>
  hr.divider {
		max-width: 3.25rem;
		border-width: 0.2rem;
		border-color: #f4623a;
	}
  </style>   

</head>
<body>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
<body class="hold-transition skin-blue layout-top-nav">

<div class="wrapper">
  <?php include_once('include/top-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="background-color: white;">

    <!-- Main content -->
    <section class="content">
          <div class="row">
            <div class="col-md-12">
              <div class="">
                <div class="box-header" align=center>
                  <i class="fa fa-money"></i>
                  <p class="box-title" style="font-size: 22px;"><b>Your Transaction Status </p>
                  <hr class="divider">
                </div>
                <div class="box-body pad table-responsive">
                  
                </div><!-- /.box -->
              </div>
            </div><!-- /.col -->

            <div class="col-md-3">
            </div>

            <div class="col-md-12">
              <!-- general form elements disabled -->
              <div class="">
                <div class="box-body pad table-responsive">
                  <?php
                    header("Pragma: no-cache");
                    header("Cache-Control: no-cache");
                    header("Expires: 0");

                    // following files need to be included
                    require_once("./lib/config_paytm.php");
                    require_once("./lib/encdec_paytm.php");

                    $paytmChecksum = "";
                    $paramList = array();
                    $isValidChecksum = "FALSE";

                    $paramList = $_POST;
                    $paytmChecksum = isset($_POST["CHECKSUMHASH"]) ? $_POST["CHECKSUMHASH"] : ""; //Sent by Paytm pg

                    //Verify all parameters received from Paytm pg to your application. Like MID received from paytm pg is same as your application�s MID, TXN_AMOUNT and ORDER_ID are same as what was sent by you to Paytm PG for initiating transaction etc.
                    $isValidChecksum = verifychecksum_e($paramList,PAYTM_MERCHANT_KEY,$paytmChecksum); //will return TRUE or FALSE string.

                    if($isValidChecksum == "TRUE") {
                      //echo "<b>Checksum matched and following are the transaction details:</b>" . "<br/>";
 	              if ($_POST["STATUS"] == "TXN_SUCCESS") {
    		        echo "<b>Transaction status is SUCCESS</b>" . "<br/>";
                        
 		        //Process your transaction here as success transaction.
   		        //Verify amount & order id received from Payment gateway with your application's order id and amount.
   		        
                      echo "<table style='border-collapse:collapse; width: 100%;'>";
                      $orderidresp = 0;
  
		        foreach($_POST as $paramName => $paramValue) {
                          switch ($paramName) {
                            case "ORDERID":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Order ID: ". "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              $orderidresp = $paramValue;
                              
                              break;

                            case "TXNID":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Transaction ID: " . "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              break;

                            case "TXNAMOUNT":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Transaction Amount (In Rupees): " . "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              break;

                            case "TXNDATE":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Transaction Date: " . "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              break;

                            case "BANKTXNID":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Bank Transaction ID: " . "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              break;

                            case "BANKNAME":
                              echo "<tr><td style='padding: 7px; border:1px solid;'>" . "Bank Name: " . "</td><td style='padding: 7px; border:1px solid;'>" . $paramValue . "</td></tr>";
                              break;                            
    
                            default:
                              //no code here
                          }
		        }

                        $sstr = explode( '-', $orderidresp );
                        $orderidresp = $sstr[1];
                        
                        #echo "Order ID: ";
                        #echo $orderidresp;
                        
                        #$sstr = split ("-", $paramValue); 
                        #$orderidresp = $sstr[1];
                              
                        $query = $db->query("SELECT customer_id FROM orders WHERE id = ".$orderidresp);
                        $row = $query->fetch_assoc();
                        $customeridresp = $row['customer_id'];                        

                        #echo "Customer ID: ";
                        #echo $customeridresp;
                        
                        $query2 = $db->query("SELECT product_id FROM order_items WHERE order_id = ".$orderidresp);                        

                        $pitems = array();
                        $i=0;
                        while($row2 = $query2->fetch_assoc()) {
                          $pitems[$i]=$row2['product_id'];
                          $i=$i+1;    
                        }      
                                     
                        $purchaseddate = date('Y-m-d');                                     

                        $validity = 0;
                        foreach ($pitems as $val) {
                          switch($val){
                            case "1":  //MF-Standard
                              $validity = 5;
                              $expiredate = date('Y-m-d', strtotime("+5 day"));
                              break;

                            case "2":  //MF-Gold
                              $validity = 30;
                              $expiredate = date('Y-m-d', strtotime("+30 day"));
                              break;

                            case "3":  //MF-Platinum
                              $validity = 90;
                              $expiredate = date('Y-m-d', strtotime("+90 day"));
                              break;

                            case "4":  //FE-Standard
                              $validity = 30;
                              $expiredate = date('Y-m-d', strtotime("+30 day"));
                              break;

                            case "5":  //FE-Gold
                              $validity = 180;
                              $expiredate = date('Y-m-d', strtotime("+180 day"));
                              break;

                            case "6":  //FE-Platinum
                              $validity = 365;
                              $expiredate = date('Y-m-d', strtotime("+365 day"));
                              break;

                            default:
                              $validity = 0;
                              break;
                          }
                           
                          if($validity != 0 && $_POST["STATUS"]=="TXN_SUCCESS"){
                            $db->query("INSERT INTO subscription (customer_id, order_id, product_id, paid_on, expire_on, status) VALUES ('$customeridresp', '$orderidresp', '$val', '$purchaseddate', '$expiredate', 'AVAILABLE')");

                            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
                            $dateNow = $date->format('Y-m-d');                  

                            if($val == "1" || $val == "2" || $val == "3") 
                              $_SESSION['MFEXAM']="AVAILABLE";                            
    
                            if($val == "4" || $val == "5" || $val == "6") 
                              $_SESSION['FEEXAM']="AVAILABLE"; 
                            
                          }
                          
                        }                                              
   
                      echo "</table>";
   		        
   		        
	              }else {
		        echo "<b>Transaction status is FAILURE</b>" . "<br/>";
	              }

                      ?>
          <!-- this row will not appear when printing -->
          <div class="row no-print" id="printbutton">
            <div class="col-xs-12" style="text-align: center;">
              <a href="#" onclick="window.print();" class="btn btn-success"><i class="fa fa-print"></i> Print</a>
            </div>
            <div class="col-xs-12" style="text-align: center;">
              
            </div>
          </div>

                    <?php
                    } else {
	              echo "<b>INVALID TRANSACTION.</b>";
       	              //Process transaction as suspicious.
                    }

                  ?>           
                </div>               
             </div>           
          </div><!-- ./row -->
    </section>
  </div>  

  <div class="no-print">  
    <?php include_once("include/footer.php"); ?>
  </div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>