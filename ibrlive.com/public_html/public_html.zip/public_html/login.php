<?php
if(session_id()=='' || !isset($_SESSION)){
    session_start();
}

if(isset($_SESSION['username'])){
  $user = $_SESSION['username'];    
  $allow = $_SESSION['userallow']; 
  $useremail = $_SESSION['useremail'];
}else{
  $user="";
  $allow="";
  $useremail="";
}

$error="";
$success="";

function random_str(
  int $length = 64,
  string $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
): string {
    if ($length < 1) {
      throw new \RangeException("Length must be a positive integer");
    }
    $pieces = [];
    $max = mb_strlen($keyspace, '8bit') - 1;
    for ($i = 0; $i < $length; ++$i) {
      $pieces []= $keyspace[random_int(0, $max)];
    }
    return implode('', $pieces);
}

if(isset($_POST['emailuser'])){
  $servername = "localhost";
  $username = "ibrlive";
  $password = "tubelight";
  $dbname = "ibrMock";

  //Create connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }   

  $error = ""; $success = "";

  $hash = "";
  $allow = "";
  $email = $_POST['emailuser']; 
  #$conn->query('SET NAMES utf8');
  
  #$email = mysql_real_escape_string("\xbf\x27 OR 1=1 /*");
  #$email = $conn->real_escape_string("OR 1=1 /*");
  
  if($email == "" ){
    exit();  
  }
  
  if($error == ""){
    $sql = "SELECT id, name, phone, paid, created, validity, amount, password FROM customers WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        $hash = $row['password'];
        $_SESSION['userid'] = $row['id'];  
        $_SESSION['sessCustomerID'] = $row['id'];
        $_SESSION['userallow'] = $row['paid'];
        $_SESSION['username'] = $row['name']; 
        $_SESSION['useremail'] = $email;  
        $_SESSION['userphone'] = $row['phone'];  
      }
      
      date_default_timezone_set('Asia/Kolkata');
      $ldate=date( 'd-m-Y h:i:s A', time () );
  
      $uip=$_SERVER['REMOTE_ADDR'];
      
        $sql = "INSERT INTO userlog (userEmail,userip,loginTime) VALUES ('$email', '$uip','$ldate')";

        if($conn->query($sql) === TRUE) {
          $successLog = "User log successfully!";
        }
    
    }else{
      $error = "Invalid Email or Password";
    }    
  }  

  $custId = $_SESSION['sessCustomerID'];
  //$dateNow = date();
  $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
  $dateNow = $date->format('Y-m-d');

  if($custId){    
    $sql2 = "SELECT * FROM `subscription` WHERE customer_id='$custId' AND status='AVAILABLE' AND expire_on >= '$dateNow' AND product_id>='1' AND product_id<='3' ORDER BY product_id DESC";
    $result2 = $conn->query($sql2);

    if ($result2->num_rows > 0) {
      $_SESSION['MFEXAM']="AVAILABLE";
    }else{
      $_SESSION['MFEXAM']="NOTAVAILABLE";
    }
    
    $sql3 = "SELECT * FROM `subscription` WHERE customer_id='$custId' AND status='AVAILABLE' AND expire_on >= '$dateNow' AND product_id>='4' AND product_id<='6' ORDER BY product_id DESC";
    $result3 = $conn->query($sql3);

    if ($result3->num_rows > 0) {
      $_SESSION['FEEXAM']="AVAILABLE";
    }else{
      $_SESSION['FEEXAM']="NOTAVAILABLE";
    }
    
    $sql4 = "SELECT * FROM `subscription` WHERE customer_id='$custId' AND status='AVAILABLE' AND expire_on >= '$dateNow' AND product_id='7' ";
    $result4 = $conn->query($sql4);

    if ($result4->num_rows > 0) {
      $_SESSION['FXPRESS']="AVAILABLE";
    }else{
      $_SESSION['FXPRESS']="NOTAVAILABLE";
    }
  } 

  if($hash==""){
      $error = "Invalid Email or Password";
  }else{    
    $auth = password_verify($_POST['passworduser'], $hash);
    if($auth == 1){
      $allow;
      $success = "Authentication successful";
      
      $randToken = random_str(15);
      $tokenHash = password_hash($randToken, PASSWORD_DEFAULT);

      $sql_i = "update customers set passcookie='$tokenHash' WHERE email='$email' ";
      $res=$conn->query($sql_i);
      if($res){
        if(!empty($_POST["remember"])) {
          setcookie("email", "$email", time()+108000, "/", "", 1);
          setcookie("token", "$randToken", time()+108000, "/", "", 1);

        }else{
          if(isset($_COOKIE['email'])){
            setcookie("email", "", time()-60, "/", "", 1);
            setcookie("token", "", time()-60, "/", "", 1);
          }
        }
      }
      
      $conn->close();
      header('Location: home.php');
      exit();
    }else{
      $user = "";    
      $allow = ""; 
      unset($_SESSION['username']);
      unset($_SESSION['userallow']);
      unset($_SESSION['member']);
      unset($_SESSION['MFEXAM']);
      unset($_SESSION['FEEXAM']);
      unset($_SESSION['FXPRESS']);
      $error = "Authentication Failed";
    }
  } 

  $conn->close();
}
?>

<!DOCTYPE html>

<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login | IBR Live</title>
  <meta name="description" content="IBR-Live Login for existing users">
  <meta name="keywords" content="login, user, ibrlive">
  
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="css/style.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
<body class="hold-transition skin-blue layout-top-nav">

<div class="wrapper">
  <?php include_once('include/top-menu.php'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  <section class="content">
    <div class="row">
      <div class="col-md-4">
      </div>

      <div class="col-md-4">        
        <div class="login-box-body">
        <div class="box-header" align=center>
             <i class="fa fa-envelope"></i>
             <p class="box-title" style="font-size: 22px;"><b>Existing User &ndash; Login Here </p>
        </div>
        <p class="login-box-msg">Sign in to start your session</p>
        <form action="" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" name="emailuser" placeholder="Email"/>
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" name="passworduser" placeholder="Password"/>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <label for="remember"><input type="checkbox" id="remember" name="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> class="" />
                          Remember me</label>
          </div>
          <div class="row">
            <div class="col-xs-8">    
                       
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
            </div><!-- /.col -->
          </div>
        </form>        
        <?php
          if($error == ""){
            if($success == ""){
            }else{
              echo "<p style=\"color: green; font-size: 16px; text-align: left;\"><b>$success</b></p>"; 
            }
          }else{
            echo "<p style=\"color: red; font-size: 16px; text-align: left;\"><b>$error</b></p>"; 
          }
        ?>
        <a href="forgot-password.php">I forgot my password</a><br>
        <a href="register.php" class="text-center">Register a new membership</a>

      </div><!-- /.login-box-body -->   
      </div>

      <div class="col-md-4">
      </div>
    </div>        
  </section>
  </div>     
  <?php include_once("include/footer.php"); ?>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>

<script>
localStorage.setItem("preVal", "2"); 
</script>
</body>
</html>
